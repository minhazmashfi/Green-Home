package com.example.gardening_project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Sunflower extends AppCompatActivity {
  EditText text4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sunflower);
        text4=findViewById(R.id.description4);
    }

    public void saveit(View view) {
        String description=text4.getText().toString();
        FirebaseDatabase db=FirebaseDatabase.getInstance();
        DatabaseReference ref4=db.getReference("Sunflower");
        ref4.setValue(description);



    }
}