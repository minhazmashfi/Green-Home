package com.example.gardening_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Informations extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_informations);
    }

    public void clickplant(View view) {
        startActivity(new Intent(getApplicationContext(), Plant.class));
        finish();
    }

    public void gardenclick(View view) {
        startActivity(new Intent(getApplicationContext(), Garden_Tools.class));
        finish();
    }

    public void othersclick(View view) {
        startActivity(new Intent(getApplicationContext(), Others.class));
        finish();
    }
    public void onBackPressed(){
        startActivity(new Intent(getApplicationContext(),MainActivity.class));
        finish();

    }

}