package com.example.gardening_project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

public class Garden_Tools extends AppCompatActivity {
    ListView Listview2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_garden__tools);
        Listview2=findViewById(R.id.listview2);
        String [] values =new String[]{
                "WheelBrawer","Rake","Pruners"
        };
        ArrayAdapter<String> flowers2=new ArrayAdapter<>(Garden_Tools.this, android.R.layout.simple_list_item_1,android.R.id.text1,values);
        Listview2.setAdapter(flowers2);
        Listview2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(position==0){
                    startActivity(new Intent(getApplicationContext(),WheelBrawer.class));
                    finish();
                }
                if(position==1){
                    startActivity(new Intent(getApplicationContext(),Rake.class));
                    finish();
                }
                if(position==2){
                    startActivity(new Intent(getApplicationContext(),Pruners.class));
                    finish();
                }
    }
});
    }
    public void onBackPressed(){
        startActivity(new Intent(getApplicationContext(),MainActivity.class));
        finish();

    }
}