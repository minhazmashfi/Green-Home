package com.example.gardening_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Orchid extends AppCompatActivity {
 EditText texto;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orchid);
        texto=findViewById(R.id.description5);
    }

    public void saveup(View view) {
        String description=texto.getText().toString();
        FirebaseDatabase db=FirebaseDatabase.getInstance();
        DatabaseReference ref6=db.getReference("Orchid");
        ref6.setValue(description);

    }
    public void onBackPressed(){
        startActivity(new Intent(getApplicationContext(),Informations.class));
        finish();

    }
}