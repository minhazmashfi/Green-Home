package com.example.gardening_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class BlackRose extends AppCompatActivity {
EditText textb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_black_rose);
        textb=findViewById(R.id.description1);
    }

    public void saveblack(View view) {
        String description=textb.getText().toString();
        FirebaseDatabase db=FirebaseDatabase.getInstance();
        DatabaseReference ref2=db.getReference("BlackRose");
        ref2.setValue(description);
    }
    public void onBackPressed(){
        startActivity(new Intent(getApplicationContext(),Informations.class));
        finish();

    }
}