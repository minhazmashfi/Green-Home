package com.example.gardening_project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class WheelBrawer extends AppCompatActivity {
EditText text92;
Button button;
DatabaseReference reff;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wheel_brawer);
        text92=findViewById(R.id.description92);
        button=findViewById(R.id.button3);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseDatabase db=FirebaseDatabase.getInstance();
                reff=db.getInstance().getReference("Wheelbraw");
                reff.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot datasnapshot) {
                        String descriptionshow=datasnapshot.getValue().toString();
                        text92.setText(descriptionshow);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

            }
        });
    }

    public void savefok(View view) {
        String description = text92.getText().toString();
        FirebaseDatabase db = FirebaseDatabase.getInstance();
        DatabaseReference ref4 = db.getReference("Wheelbrawer");
        ref4.setValue(description);
    }
        public void onBackPressed(){
            startActivity(new Intent(getApplicationContext(),Informations.class));
            finish();

        }

}