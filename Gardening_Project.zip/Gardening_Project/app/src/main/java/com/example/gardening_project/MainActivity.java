package com.example.gardening_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {
    Button weather;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button weather=findViewById(R.id.weatherforcast);

        weather.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),Weather_forcast.class));
                finish();

            }
        });
    }

    public void onlogout(View view) {
        FirebaseAuth.getInstance().signOut();
        startActivity(new Intent(getApplicationContext(),Login.class));
        finish();
    }
    public void clickme(View view ){
        startActivity(new Intent(getApplicationContext(),Informations.class));
        finish();


    }

    public void clicking(View view) {
        startActivity(new Intent(getApplicationContext(),Tracker.class));
        finish();
    }


    }
