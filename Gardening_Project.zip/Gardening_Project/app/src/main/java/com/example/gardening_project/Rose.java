package com.example.gardening_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Rose extends AppCompatActivity {
    EditText textlast;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rose);
        textlast=findViewById(R.id.description2);
    }

    public void Saveem(View view) {
        String description=textlast.getText().toString();
        FirebaseDatabase db=FirebaseDatabase.getInstance();
        DatabaseReference ref4=db.getReference("Rose");
        ref4.setValue(description);
    }
    public void onBackPressed(){
        startActivity(new Intent(getApplicationContext(),Informations.class));
        finish();

    }
}