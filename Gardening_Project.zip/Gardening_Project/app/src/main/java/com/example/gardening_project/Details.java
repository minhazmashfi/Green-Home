package com.example.gardening_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class Details extends AppCompatActivity {
    Button button1,button2,button3,button4,button5;
    EditText count1,count2,count3,count4,count5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        Button button1=findViewById(R.id.button1);

        Button button2=findViewById(R.id.button20);
        Button button3=findViewById(R.id.button30);
        Button button4=findViewById(R.id.button40);
        Button button5=findViewById(R.id.button50);

    }

    public void buttonclick(View view) {
        String description=count1.getText().toString();
        FirebaseDatabase db=FirebaseDatabase.getInstance();
        DatabaseReference ref4=db.getReference("SunflowC");
        ref4.setValue(description);
    }

    public void clickgo(View view) {
        String description=count2.getText().toString();
        FirebaseDatabase db=FirebaseDatabase.getInstance();
        DatabaseReference ref4=db.getReference("RoseC");
        ref4.setValue(description);
    }

    public void Clicksum(View view) {
        String description=count3.getText().toString();
        FirebaseDatabase db=FirebaseDatabase.getInstance();
        DatabaseReference ref4=db.getReference("OrchidC");
        ref4.setValue(description);
    }

    public void Clickall(View view) {
        String description=count4.getText().toString();
        FirebaseDatabase db=FirebaseDatabase.getInstance();
        DatabaseReference ref4=db.getReference("TulipC");
        ref4.setValue(description);
    }

    public void clickme(View view) {
        String description=count5.getText().toString();
        FirebaseDatabase db=FirebaseDatabase.getInstance();
        DatabaseReference ref4=db.getReference("BlackRoseC");
        ref4.setValue(description);
    }
    public void onBackPressed() {
        startActivity(new Intent(getApplicationContext(), MainActivity.class));
        finish();
    }
}