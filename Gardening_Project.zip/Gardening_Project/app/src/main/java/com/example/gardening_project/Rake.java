package com.example.gardening_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Rake extends AppCompatActivity {
EditText text10;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rake);
        text10=findViewById(R.id.description11);
    }

    public void savealll(View view) {
        String description=text10.getText().toString();
        FirebaseDatabase db=FirebaseDatabase.getInstance();
        DatabaseReference ref10=db.getReference("Rake");
        ref10.setValue(description);
    }
    public void onBackPressed(){
        startActivity(new Intent(getApplicationContext(),Informations.class));
        finish();

    }
}