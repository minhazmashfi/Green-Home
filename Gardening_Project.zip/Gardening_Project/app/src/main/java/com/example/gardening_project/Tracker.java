package com.example.gardening_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Tracker extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tracker);
    }

    public void detailsclick(View view) {
        startActivity(new Intent(getApplicationContext(),Details.class));
        finish();
    }

    public void reminderclick(View view) {
        startActivity(new Intent(getApplicationContext(),reminder.class));
        finish();
    }
    public void onBackPressed() {
        startActivity(new Intent(getApplicationContext(), MainActivity.class));
        finish();
    }
}