package com.example.gardening_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Pruners extends AppCompatActivity {
        EditText text22;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pruners);
        text22=findViewById(R.id.description22);
    }
    public void saveon(View view){
        String description=text22.getText().toString();
        FirebaseDatabase db=FirebaseDatabase.getInstance();
        DatabaseReference ref22=db.getReference("Pruners");
        ref22.setValue(description);

    }
    public void onBackPressed(){
        startActivity(new Intent(getApplicationContext(),Informations.class));
        finish();

    }
}